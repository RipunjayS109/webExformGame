// server-ui.js - UI logic for the server page
document.addEventListener('DOMContentLoaded', () => {
    const statusElement = document.getElementById('status');
    const toggleButton = document.getElementById('toggleServer');
    const ipAddressElement = document.getElementById('ipAddress');
    
    let serverRunning = false;
    
    // Function to get local IP address
    async function getLocalIP() {
        try {
            // Use a public STUN server to get the local IP
            const pc = new RTCPeerConnection({
                iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
            });
            
            // Create a data channel to trigger ICE gathering
            pc.createDataChannel('');
            
            // Create an offer to trigger ICE gathering
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            
            // Wait for ICE gathering to complete
            return new Promise((resolve) => {
                pc.onicecandidate = (event) => {
                    if (!event.candidate) {
                        pc.close();
                        return;
                    }
                    
                    // Extract IP from the candidate
                    const ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3})/;
                    const match = ipRegex.exec(event.candidate.candidate);
                    
                    if (match && match[1] && !match[1].startsWith('192.168.') && !match[1].startsWith('10.') && !match[1].startsWith('172.')) {
                        pc.close();
                        resolve(match[1]);
                    }
                };
                
                // Timeout after 5 seconds
                setTimeout(() => {
                    pc.close();
                    resolve('localhost');
                }, 5000);
            });
        } catch (error) {
            console.error('Error getting local IP:', error);
            return 'localhost';
        }
    }
    
    // Update the UI with the local IP
    async function updateLocalIP() {
        const ip = await getLocalIP();
        ipAddressElement.textContent = ip;
    }
    
    // Toggle server state
    toggleButton.addEventListener('click', () => {
        if (!serverRunning) {
            // Start the server
            startServer();
        } else {
            // Stop the server
            stopServer();
        }
    });
    
    // Start the server
    function startServer() {
        // In a real implementation, this would start a server
        // For this demo, we'll just simulate it
        serverRunning = true;
        statusElement.textContent = 'Server is running';
        statusElement.className = 'status running';
        toggleButton.textContent = 'Stop Server';
        
        // Update the local IP
        updateLocalIP();
        
        // Notify the background script that the server is running
        chrome.runtime.sendMessage({ action: 'serverStarted' });
    }
    
    // Stop the server
    function stopServer() {
        // In a real implementation, this would stop the server
        // For this demo, we'll just simulate it
        serverRunning = false;
        statusElement.textContent = 'Server is not running';
        statusElement.className = 'status stopped';
        toggleButton.textContent = 'Start Server';
        
        // Notify the background script that the server is stopped
        chrome.runtime.sendMessage({ action: 'serverStopped' });
    }
    
    // Initialize
    updateLocalIP();
}); 