// start-server.js - Script to start the local server directly
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const os = require('os');

// Default port
const PORT = 8080;

// MIME types for different file extensions
const MIME_TYPES = {
    '.html': 'text/html',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// Function to get local IP address
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            // Skip internal and non-IPv4 addresses
            if (!iface.internal && iface.family === 'IPv4') {
                return iface.address;
            }
        }
    }
    return 'localhost';
}

// Create HTTP server
const server = http.createServer((req, res) => {
    // Parse URL and get pathname
    const parsedUrl = url.parse(req.url);
    let pathname = parsedUrl.pathname;
    
    // Default to index.html for root path
    if (pathname === '/') {
        pathname = '/play.html';
    }
    
    // Get file extension
    const ext = path.parse(pathname).ext;
    
    // Set content type based on file extension
    const contentType = MIME_TYPES[ext] || 'text/plain';
    
    // Read file from disk
    fs.readFile(path.join(__dirname, pathname), (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // File not found
                fs.readFile(path.join(__dirname, '404.html'), (err, content) => {
                    res.writeHead(404, { 'Content-Type': 'text/html' });
                    res.end(content, 'utf-8');
                });
            } else {
                // Server error
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            // Success
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

// Start server
server.listen(PORT, '0.0.0.0', () => {
    const localIP = getLocalIP();
    console.log(`Server running at http://localhost:${PORT}/`);
    console.log(`Local network access: http://${localIP}:${PORT}/`);
    console.log(`Share this URL with students on your local network`);
    console.log(`Press Ctrl+C to stop the server`);
});

// Handle server shutdown
process.on('SIGINT', () => {
    console.log('Shutting down server...');
    server.close(() => {
        console.log('Server stopped');
        process.exit(0);
    });
}); 