// analytics.js - Data visualization and reporting for quiz results
class QuizAnalytics {
    constructor() {
        this.results = [];
        this.quizzes = [];
        this.selectedQuizId = null;
        this.loadData();
    }

    async loadData() {
        try {
            const data = await this.getStorageData(['quizResults', 'quizzes']);
            this.results = data.quizResults || [];
            this.quizzes = data.quizzes || [];

            this.initializeUI();
        } catch (error) {
            console.error('Failed to load data:', error);
            document.getElementById('analytics-container').innerHTML = `
          <div class="error-message">
            <h2>Error Loading Data</h2>
            <p>${error.message}</p>
          </div>
        `;
        }
    }

    getStorageData(keys) {
        return new Promise((resolve, reject) => {
            chrome.storage.local.get(keys, (data) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(data);
                }
            });
        });
    }

    initializeUI() {
        const container = document.getElementById('analytics-container');

        if (this.quizzes.length === 0) {
            container.innerHTML = `
          <div class="no-data-message">
            <h2>No Quizzes Available</h2>
            <p>You haven't created any quizzes yet. Create a quiz to view analytics.</p>
            <button id="create-quiz-btn">Create Quiz</button>
          </div>
        `;
            document.getElementById('create-quiz-btn').addEventListener('click', () => {
                window.location.href = 'quiz-builder.html';
            });
            return;
        }

        // Create quiz selector
        const quizOptions = this.quizzes.map(quiz =>
            `<option value="${quiz.id}">${quiz.title}</option>`
        ).join('');

        container.innerHTML = `
        <div class="analytics-header">
          <h1>Quiz Analytics</h1>
          <div class="quiz-selector">
            <label for="quiz-select">Select Quiz:</label>
            <select id="quiz-select">
              <option value="">-- Select a Quiz --</option>
              ${quizOptions}
            </select>
          </div>
        </div>
        
        <div id="analytics-content" class="analytics-content">
          <div class="no-selection-message">
            <p>Select a quiz from the dropdown to view analytics.</p>
          </div>
        </div>
      `;

        // Add event listener to quiz selector
        document.getElementById('quiz-select').addEventListener('change', (e) => {
            this.selectedQuizId = e.target.value;
            if (this.selectedQuizId) {
                this.renderQuizAnalytics(this.selectedQuizId);
            } else {
                document.getElementById('analytics-content').innerHTML = `
            <div class="no-selection-message">
              <p>Select a quiz from the dropdown to view analytics.</p>
            </div>
          `;
            }
        });
    }

    renderQuizAnalytics(quizId) {
        const quiz = this.quizzes.find(q => q.id === quizId);
        const quizResults = this.results.filter(r => r.quizId === quizId);

        if (!quiz) {
            console.error('Quiz not found:', quizId);
            return;
        }

        const contentContainer = document.getElementById('analytics-content');

        if (quizResults.length === 0) {
            contentContainer.innerHTML = `
          <div class="no-data-message">
            <h2>No Data Available</h2>
            <p>No one has taken this quiz yet.</p>
            <h3>Share this quiz:</h3>
            <div class="share-link">
              <input type="text" readonly value="${this.getQuizShareUrl(quizId)}" id="share-url">
              <button id="copy-link-btn">Copy</button>
            </div>
          </div>
        `;

            document.getElementById('copy-link-btn').addEventListener('click', () => {
                const shareUrl = document.getElementById('share-url');
                shareUrl.select();
                document.execCommand('copy');
                alert('Link copied to clipboard!');
            });

            return;
        }

        // Generate overall stats
        const totalAttempts = quizResults.length;
        const completedAttempts = quizResults.filter(r => r.completionStatus === 'complete').length;
        const avgScore = Math.round(quizResults.reduce((sum, r) => sum + r.score, 0) / totalAttempts);
        const avgTimeSpent = Math.round(quizResults.reduce((sum, r) => sum + r.timePlayed, 0) / totalAttempts);

        // Question difficulty analysis
        const questionStats = [];
        for (let i = 0; i < quiz.questions.length; i++) {
            const questionData = {
                index: i,
                text: quiz.questions[i].text.substring(0, 30) + (quiz.questions[i].text.length > 30 ? '...' : ''),
                attempts: 0,
                correct: 0,
                avgTime: 0
            };

            let totalTime = 0;
            quizResults.forEach(result => {
                result.answers.forEach(answer => {
                    if (answer.questionIndex === i) {
                        questionData.attempts++;
                        if (answer.correct) questionData.correct++;
                        totalTime += answer.timeSpent;
                    }
                });
            });

            questionData.avgTime = questionData.attempts > 0 ? Math.round(totalTime / questionData.attempts) : 0;
            questionData.correctPercentage = questionData.attempts > 0 ? Math.round((questionData.correct / questionData.attempts) * 100) : 0;

            questionStats.push(questionData);
        }

        // Student performance tracking
        const studentPerformance = {};
        quizResults.forEach(result => {
            const studentId = `${result.player.name}-${result.player.rollNo}`;
            if (!studentPerformance[studentId]) {
                studentPerformance[studentId] = {
                    name: result.player.name,
                    rollNo: result.player.rollNo,
                    attempts: 0,
                    totalScore: 0,
                    avgScore: 0,
                    bestScore: 0,
                    completionRate: 0
                };
            }
            
            studentPerformance[studentId].attempts++;
            studentPerformance[studentId].totalScore += result.score;
            studentPerformance[studentId].avgScore = Math.round(studentPerformance[studentId].totalScore / studentPerformance[studentId].attempts);
            studentPerformance[studentId].bestScore = Math.max(studentPerformance[studentId].bestScore, result.score);
            if (result.completionStatus === 'complete') {
                studentPerformance[studentId].completionRate++;
            }
        });
        
        // Convert student performance to array for easier rendering
        const studentPerformanceArray = Object.values(studentPerformance).map(student => ({
            ...student,
            completionRate: Math.round((student.completionRate / student.attempts) * 100)
        }));
        
        // Sort by score (descending)
        studentPerformanceArray.sort((a, b) => b.bestScore - a.bestScore);
        
        // Render analytics
        contentContainer.innerHTML = `
          <div class="analytics-summary">
            <h2>Quiz Summary</h2>
            <div class="summary-stats">
              <div class="stat-box">
                <h3>Total Attempts</h3>
                <p>${totalAttempts}</p>
              </div>
              <div class="stat-box">
                <h3>Completed</h3>
                <p>${completedAttempts} (${Math.round((completedAttempts / totalAttempts) * 100)}%)</p>
              </div>
              <div class="stat-box">
                <h3>Average Score</h3>
                <p>${avgScore}</p>
              </div>
              <div class="stat-box">
                <h3>Avg. Time</h3>
                <p>${this.formatTime(avgTimeSpent)}</p>
              </div>
            </div>
          </div>
          
          <div class="question-analytics">
            <h2>Question Analysis</h2>
            <div class="question-stats">
              ${questionStats.map(q => `
                <div class="question-stat-box">
                  <h4>Q${q.index + 1}: ${q.text}</h4>
                  <div class="stat-row">
                    <span>Correct: ${q.correctPercentage}%</span>
                    <span>Avg. Time: ${this.formatTime(q.avgTime)}</span>
                  </div>
                  <div class="progress-bar">
                    <div class="progress" style="width: ${q.correctPercentage}%"></div>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
          
          <div class="student-performance">
            <h2>Student Performance</h2>
            <table class="student-table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>Roll No.</th>
                  <th>Best Score</th>
                  <th>Avg. Score</th>
                  <th>Attempts</th>
                  <th>Completion Rate</th>
                </tr>
              </thead>
              <tbody>
                ${studentPerformanceArray.map((student, index) => `
                  <tr>
                    <td>${index + 1}</td>
                    <td>${student.name}</td>
                    <td>${student.rollNo}</td>
                    <td>${student.bestScore}</td>
                    <td>${student.avgScore}</td>
                    <td>${student.attempts}</td>
                    <td>${student.completionRate}%</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `;
    }
    
    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
    
    getQuizShareUrl(quizId) {
        // Get the local server URL from background script
        return `http://localhost:8080/play.html?id=${quizId}`;
    }
}

// Initialize analytics when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const analytics = new QuizAnalytics();
});