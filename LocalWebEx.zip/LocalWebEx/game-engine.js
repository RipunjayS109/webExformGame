class QuizGame {
    constructor(quizData, playerInfo) {
        this.quiz = quizData;
        this.playerInfo = playerInfo;
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.lives = quizData.lives || 3;
        this.timeLeft = quizData.timeLimit || 0;
        this.timer = null;
        this.gameStartTime = null;
        this.questionStartTime = null;
        this.questionTimes = [];
        this.answers = [];

        // Game elements
        this.characterPosition = 0;
        this.trackLength = 100; // Percentage
        this.stepSize = this.trackLength / quizData.questions.length;

        // Initialize UI
        this.initializeGameUI();
    }

    initializeGameUI() {
        const gameContainer = document.getElementById('game-container');

        // Build game interface
        gameContainer.innerHTML = `
        <div class="game-header">
          <div class="player-info">
            <span>${this.playerInfo.name} (${this.playerInfo.rollNo})</span>
          </div>
          <div class="game-stats">
            <div class="lives">Lives: <span id="lives-count">${this.lives}</span></div>
            ${this.quiz.timeLimit ? `<div class="timer">Time: <span id="time-left">${this.formatTime(this.quiz.timeLimit)}</span></div>` : ''}
            <div class="score">Score: <span id="score-display">0</span></div>
          </div>
        </div>
        
        <div class="game-track">
          <div class="track-line"></div>
          <div id="character" class="character"></div>
          <div class="finish-line"></div>
        </div>
        
        <div id="question-container" class="question-container">
          <!-- Question will be displayed here -->
        </div>
        
        <div id="answers-container" class="answers-container">
          <!-- Answer options will be displayed here -->
        </div>
        
        <div id="feedback" class="feedback hidden"></div>
      `;

        // Start the game
        this.startGame();
    }

    startGame() {
        this.gameStartTime = Date.now();
        this.showQuestion(0);

        // Start timer if there's a time limit
        if (this.quiz.timeLimit > 0) {
            this.timeLeft = this.quiz.timeLimit;
            this.startTimer();
        }
    }

    startTimer() {
        const timerDisplay = document.getElementById('time-left');

        this.timer = setInterval(() => {
            this.timeLeft -= 1;
            timerDisplay.textContent = this.formatTime(this.timeLeft);

            if (this.timeLeft <= 0) {
                clearInterval(this.timer);
                this.endGame('timeout');
            }
        }, 1000);
    }

    formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    showQuestion(index) {
        if (index >= this.quiz.questions.length) {
            this.endGame('complete');
            return;
        }

        this.currentQuestionIndex = index;
        this.questionStartTime = Date.now();

        const question = this.quiz.questions[index];
        const questionContainer = document.getElementById('question-container');
        const answersContainer = document.getElementById('answers-container');

        // Display question
        questionContainer.innerHTML = `
        <h2>Question ${index + 1}</h2>
        <div class="question-content">
          <p>${question.text}</p>
          ${question.type === 'image' && question.image ? `<img src="${question.image}" alt="Question Image" class="question-image">` : ''}
        </div>
      `;

        // Shuffle answers to avoid patterns
        const shuffledAnswers = this.shuffleArray([...question.answers]);

        // Display answer options
        answersContainer.innerHTML = shuffledAnswers.map((answer, i) => `
        <div class="answer-option" data-index="${i}" data-correct="${answer.correct}">
          ${answer.text}
        </div>
      `).join('');

        // Add click event listeners to answers
        document.querySelectorAll('.answer-option').forEach(option => {
            option.addEventListener('click', (e) => this.checkAnswer(e.target));
        });
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    checkAnswer(selectedOption) {
        const isCorrect = selectedOption.dataset.correct === 'true';
        const answerTime = Math.round((Date.now() - this.questionStartTime) / 1000);

        // Store answer data for analytics
        this.answers.push({
            questionIndex: this.currentQuestionIndex,
            correct: isCorrect,
            timeSpent: answerTime
        });

        // Show feedback
        const feedback = document.getElementById('feedback');
        feedback.textContent = isCorrect ? 'Correct!' : 'Incorrect!';
        feedback.className = `feedback ${isCorrect ? 'correct' : 'incorrect'}`;

        // Disable all answer options
        document.querySelectorAll('.answer-option').forEach(option => {
            option.classList.add('disabled');
            if (option.dataset.correct === 'true') {
                option.classList.add('correct-answer');
            }
        });

        // Highlight selected answer
        selectedOption.classList.add(isCorrect ? 'correct-selected' : 'incorrect-selected');

        if (isCorrect) {
            // Increase score
            this.score += 100;
            document.getElementById('score-display').textContent = this.score;

            // Move character forward
            this.moveCharacter();

            // Wait and show next question
            setTimeout(() => {
                feedback.classList.add('hidden');
                this.showQuestion(this.currentQuestionIndex + 1);
            }, 1500);
        } else {
            // Reduce lives
            this.lives--;
            document.getElementById('lives-count').textContent = this.lives;

            if (this.lives <= 0) {
                // Game over if no lives left
                setTimeout(() => {
                    this.endGame('no-lives');
                }, 1500);
            } else {
                // Continue with same question if lives remain
                setTimeout(() => {
                    feedback.classList.add('hidden');
                    // Keep same question but reset the options
                    const answersContainer = document.getElementById('answers-container');
                    const question = this.quiz.questions[this.currentQuestionIndex];
                    const shuffledAnswers = this.shuffleArray([...question.answers]);

                    answersContainer.innerHTML = shuffledAnswers.map((answer, i) => `
              <div class="answer-option" data-index="${i}" data-correct="${answer.correct}">
                ${answer.text}
              </div>
            `).join('');

                    document.querySelectorAll('.answer-option').forEach(option => {
                        option.addEventListener('click', (e) => this.checkAnswer(e.target));
                    });
                }, 1500);
            }
        }
    }

    moveCharacter() {
        this.characterPosition += this.stepSize;
        const character = document.getElementById('character');
        character.style.left = `${this.characterPosition}%`;

        // Add animation class
        character.classList.add('character-jump');
        setTimeout(() => {
            character.classList.remove('character-jump');
        }, 500);
    }

    endGame(reason) {
        // Clear timer
        if (this.timer) {
            clearInterval(this.timer);
        }

        // Calculate total time played
        const totalPlayTime = Math.round((Date.now() - this.gameStartTime) / 1000);

        // Prepare results data
        const results = {
            player: this.playerInfo,
            quizId: this.quiz.id,
            quizTitle: this.quiz.title,
            score: this.score,
            livesRemaining: this.lives,
            timePlayed: totalPlayTime,
            completionStatus: reason,
            answers: this.answers,
            timestamp: new Date().toISOString()
        };

        // Save results to local storage for analytics
        this.saveResults(results);

        // Show game over screen
        const gameContainer = document.getElementById('game-container');
        const gameOver = document.getElementById('game-over');
        
        // Hide game container and show game over screen
        gameContainer.classList.add('hidden');
        gameOver.classList.remove('hidden');
        
        // Display game result
        const gameResult = document.getElementById('game-result');
        
        let resultMessage = '';
        let resultClass = '';
        
        switch (reason) {
            case 'complete':
                resultMessage = `
                    <h2>Congratulations!</h2>
                    <p>You've completed the quiz!</p>
                    <div class="result-stats">
                        <div class="stat">
                            <span class="stat-label">Final Score:</span>
                            <span class="stat-value">${this.score}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Time:</span>
                            <span class="stat-value">${this.formatTime(totalPlayTime)}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Lives Remaining:</span>
                            <span class="stat-value">${this.lives}</span>
                        </div>
                    </div>
                `;
                resultClass = 'success';
                break;
            case 'timeout':
                resultMessage = `
                    <h2>Time's Up!</h2>
                    <p>You ran out of time to complete the quiz.</p>
                    <div class="result-stats">
                        <div class="stat">
                            <span class="stat-label">Final Score:</span>
                            <span class="stat-value">${this.score}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Questions Completed:</span>
                            <span class="stat-value">${this.currentQuestionIndex}</span>
                        </div>
                    </div>
                `;
                resultClass = 'warning';
                break;
            case 'no-lives':
                resultMessage = `
                    <h2>Game Over</h2>
                    <p>You've run out of lives!</p>
                    <div class="result-stats">
                        <div class="stat">
                            <span class="stat-label">Final Score:</span>
                            <span class="stat-value">${this.score}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Questions Completed:</span>
                            <span class="stat-value">${this.currentQuestionIndex}</span>
                        </div>
                    </div>
                `;
                resultClass = 'error';
                break;
            default:
                resultMessage = `
                    <h2>Quiz Ended</h2>
                    <p>The quiz has ended.</p>
                    <div class="result-stats">
                        <div class="stat">
                            <span class="stat-label">Final Score:</span>
                            <span class="stat-value">${this.score}</span>
                        </div>
                    </div>
                `;
                resultClass = 'info';
        }
        
        gameResult.innerHTML = `<div class="result-message ${resultClass}">${resultMessage}</div>`;
    }

    saveResults(results) {
        // In a real implementation, this would send data to the local server
        // For this demo, we'll use chrome.storage to simulate the server
        chrome.storage.local.get('quizResults', (data) => {
            const quizResults = data.quizResults || [];
            quizResults.push(results);
            
            chrome.storage.local.set({ quizResults }, () => {
                console.log('Results saved successfully');
            });
        });
    }
}

// Export the QuizGame class for use in other files
window.QuizGame = QuizGame;

// Initialize game when page loads
document.addEventListener('DOMContentLoaded', () => {
    // Get quiz ID and player info from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('quizId');
    const playerName = urlParams.get('name');
    const playerRollNo = urlParams.get('rollNo');

    if (!quizId || !playerName || !playerRollNo) {
        document.getElementById('game-container').innerHTML = `
        <div class="error-message">
          <h2>Missing Information</h2>
          <p>Please make sure you have a valid quiz link with player information.</p>
          <button onclick="window.history.back()">Go Back</button>
        </div>
      `;
        return;
    }

    // Get quiz data from storage
    chrome.storage.local.get('quizzes', (data) => {
        const quizzes = data.quizzes || [];
        const quiz = quizzes.find(q => q.id === quizId);

        if (quiz) {
            // Initialize game with quiz data and player info
            new QuizGame(quiz, { name: playerName, rollNo: playerRollNo });
        } else {
            document.getElementById('game-container').innerHTML = `
          <div class="error-message">
            <h2>Quiz Not Found</h2>
            <p>The requested quiz could not be found.</p>
            <button onclick="window.history.back()">Go Back</button>
          </div>
        `;
        }
    });
});