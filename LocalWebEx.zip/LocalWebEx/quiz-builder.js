// quiz-builder.js - Interface for teachers to create quizzes
class QuizBuilder {
    constructor() {
      this.quiz = {
        title: "",
        description: "",
        timeLimit: 0, // 0 means no time limit
        lives: 3, // Default lives
        questions: []
      };
      this.setupEventListeners();
    }
  
    setupEventListeners() {
      document.getElementById('add-question').addEventListener('click', () => this.addQuestionForm());
      document.getElementById('save-quiz').addEventListener('click', () => this.saveQuiz());
      document.getElementById('quiz-title').addEventListener('input', (e) => this.quiz.title = e.target.value);
      document.getElementById('quiz-description').addEventListener('input', (e) => this.quiz.description = e.target.value);
      document.getElementById('time-limit').addEventListener('input', (e) => this.quiz.timeLimit = parseInt(e.target.value, 10));
      document.getElementById('lives').addEventListener('input', (e) => this.quiz.lives = parseInt(e.target.value, 10));
    }
  
    addQuestionForm(existingQuestion = null) {
      const questionId = Date.now().toString();
      const questionsContainer = document.getElementById('questions-container');
      
      const questionDiv = document.createElement('div');
      questionDiv.className = 'question-form';
      questionDiv.dataset.id = questionId;
      
      questionDiv.innerHTML = `
        <h3>Question</h3>
        <select class="question-type">
          <option value="text" ${existingQuestion && existingQuestion.type === 'text' ? 'selected' : ''}>Text</option>
          <option value="image" ${existingQuestion && existingQuestion.type === 'image' ? 'selected' : ''}>Image</option>
        </select>
        <div class="question-content">
          <textarea class="question-text" placeholder="Enter your question">${existingQuestion ? existingQuestion.text : ''}</textarea>
          <div class="image-upload ${existingQuestion && existingQuestion.type === 'image' ? '' : 'hidden'}">
            <input type="file" accept="image/*" class="question-image-upload">
            <div class="image-preview"></div>
          </div>
        </div>
        <h4>Answers</h4>
        <div class="answers-container">
          ${this.generateAnswerInputs(existingQuestion?.answers || [{text: '', correct: true}, {text: '', correct: false}, {text: '', correct: false}, {text: '', correct: false}])}
        </div>
        <button type="button" class="remove-question">Remove Question</button>
      `;
      
      questionsContainer.appendChild(questionDiv);
      
      // Setup event listeners for the new question
      const questionType = questionDiv.querySelector('.question-type');
      questionType.addEventListener('change', (e) => {
        const imageUpload = questionDiv.querySelector('.image-upload');
        if (e.target.value === 'image') {
          imageUpload.classList.remove('hidden');
        } else {
          imageUpload.classList.add('hidden');
        }
      });
      
      questionDiv.querySelector('.remove-question').addEventListener('click', () => {
        questionDiv.remove();
      });
      
      // Image upload preview
      const imageUpload = questionDiv.querySelector('.question-image-upload');
      imageUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const imgPreview = questionDiv.querySelector('.image-preview');
            imgPreview.innerHTML = `<img src="${event.target.result}" alt="Question Image">`;
          };
          reader.readAsDataURL(file);
        }
      });
      
      // Handle correct answer selection
      const radioButtons = questionDiv.querySelectorAll('.is-correct');
      radioButtons.forEach(radio => {
        radio.addEventListener('change', (e) => {
          // Uncheck all other radios in this question
          radioButtons.forEach(r => {
            if (r !== e.target) r.checked = false;
          });
        });
      });
    }
    
    generateAnswerInputs(answers) {
      return answers.map((answer, index) => `
        <div class="answer-row">
          <input type="radio" name="correct-${Date.now()}" class="is-correct" ${answer.correct ? 'checked' : ''}>
          <input type="text" class="answer-text" placeholder="Answer option" value="${answer.text}">
        </div>
      `).join('');
    }
    
    collectQuestionData() {
      const questions = [];
      document.querySelectorAll('.question-form').forEach(questionDiv => {
        const questionType = questionDiv.querySelector('.question-type').value;
        const questionText = questionDiv.querySelector('.question-text').value;
        
        let questionImageData = null;
        if (questionType === 'image') {
          const imgElement = questionDiv.querySelector('.image-preview img');
          if (imgElement) {
            questionImageData = imgElement.src;
          }
        }
        
        const answers = [];
        questionDiv.querySelectorAll('.answer-row').forEach(answerRow => {
          answers.push({
            text: answerRow.querySelector('.answer-text').value,
            correct: answerRow.querySelector('.is-correct').checked
          });
        });
        
        questions.push({
          id: questionDiv.dataset.id,
          type: questionType,
          text: questionText,
          image: questionImageData,
          answers: answers
        });
      });
      
      return questions;
    }
    
    saveQuiz() {
      this.quiz.questions = this.collectQuestionData();
      
      // Validate quiz
      if (!this.quiz.title) {
        alert('Please enter a quiz title');
        return;
      }
      
      if (this.quiz.questions.length === 0) {
        alert('Please add at least one question');
        return;
      }
      
      // Check if all questions have at least one correct answer
      const invalidQuestions = this.quiz.questions.filter(q => 
        !q.answers.some(a => a.correct) || 
        q.answers.filter(a => a.text.trim()).length < 2
      );
      
      if (invalidQuestions.length > 0) {
        alert('All questions must have at least one correct answer and at least two non-empty answer options');
        return;
      }
      
      // Save to Chrome storage
      chrome.storage.local.get('quizzes', (data) => {
        const quizzes = data.quizzes || [];
        
        // Check if we're editing an existing quiz or adding a new one
        const existingIndex = quizzes.findIndex(q => q.id === this.quiz.id);
        if (existingIndex >= 0) {
          quizzes[existingIndex] = this.quiz;
        } else {
          this.quiz.id = Date.now().toString();
          this.quiz.createdAt = new Date().toISOString();
          quizzes.push(this.quiz);
        }
        
        chrome.storage.local.set({quizzes}, () => {
          alert('Quiz saved successfully!');
          // Redirect to quiz management page
          window.location.href = 'manage-quizzes.html';
        });
      });
    }
    
    loadQuiz(quizId) {
      chrome.storage.local.get('quizzes', (data) => {
        const quizzes = data.quizzes || [];
        const quiz = quizzes.find(q => q.id === quizId);
        
        if (quiz) {
          this.quiz = quiz;
          
          // Populate the form
          document.getElementById('quiz-title').value = quiz.title;
          document.getElementById('quiz-description').value = quiz.description;
          document.getElementById('time-limit').value = quiz.timeLimit;
          document.getElementById('lives').value = quiz.lives;
          
          // Clear existing questions
          document.getElementById('questions-container').innerHTML = '';
          
          // Add question forms
          quiz.questions.forEach(question => {
            this.addQuestionForm(question);
          });
        }
      });
    }
  }
  
  // Initialize the quiz builder when the page loads
  document.addEventListener('DOMContentLoaded', () => {
    const builder = new QuizBuilder();
    
    // Check if we're editing an existing quiz
    const urlParams = new URLSearchParams(window.location.search);
    const quizId = urlParams.get('id');
    
    if (quizId) {
      builder.loadQuiz(quizId);
    }
  });