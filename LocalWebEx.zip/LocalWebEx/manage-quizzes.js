// manage-quizzes.js - Handles quiz management functionality

class QuizManager {
    constructor() {
        this.quizzes = [];
        this.loadQuizzes();
    }

    loadQuizzes() {
        chrome.storage.local.get('quizzes', (data) => {
            this.quizzes = data.quizzes || [];
            this.renderQuizzes();
        });
    }

    renderQuizzes() {
        const container = document.getElementById('quizzes-container');
        
        if (this.quizzes.length === 0) {
            container.innerHTML = `
                <div class="no-data-message">
                    <h2>No Quizzes Available</h2>
                    <p>You haven't created any quizzes yet.</p>
                    <a href="quiz-builder.html" class="btn primary-btn">Create Your First Quiz</a>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="quizzes-list">
                ${this.quizzes.map(quiz => this.renderQuizCard(quiz)).join('')}
            </div>
        `;

        // Add event listeners to action buttons
        document.querySelectorAll('.edit-quiz-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const quizId = e.target.dataset.id;
                window.location.href = `quiz-builder.html?id=${quizId}`;
            });
        });

        document.querySelectorAll('.delete-quiz-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const quizId = e.target.dataset.id;
                this.deleteQuiz(quizId);
            });
        });

        document.querySelectorAll('.share-quiz-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const quizId = e.target.dataset.id;
                this.shareQuiz(quizId);
            });
        });
    }

    renderQuizCard(quiz) {
        const questionCount = quiz.questions.length;
        const timeLimit = quiz.timeLimit > 0 ? `${quiz.timeLimit} seconds` : 'No limit';
        const lives = quiz.lives > 0 ? quiz.lives : 'Infinite';
        const createdAt = new Date(quiz.createdAt).toLocaleDateString();
        
        return `
            <div class="quiz-card">
                <div class="quiz-card-header">
                    <h3>${quiz.title}</h3>
                    <span class="quiz-date">Created: ${createdAt}</span>
                </div>
                
                <div class="quiz-card-body">
                    <p>${quiz.description || 'No description'}</p>
                    <div class="quiz-stats">
                        <div class="stat">
                            <span class="stat-label">Questions:</span>
                            <span class="stat-value">${questionCount}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Time Limit:</span>
                            <span class="stat-value">${timeLimit}</span>
                        </div>
                        <div class="stat">
                            <span class="stat-label">Lives:</span>
                            <span class="stat-value">${lives}</span>
                        </div>
                    </div>
                </div>
                
                <div class="quiz-card-actions">
                    <button class="edit-quiz-btn" data-id="${quiz.id}">Edit</button>
                    <button class="share-quiz-btn" data-id="${quiz.id}">Share</button>
                    <button class="delete-quiz-btn" data-id="${quiz.id}">Delete</button>
                </div>
            </div>
        `;
    }

    deleteQuiz(quizId) {
        if (confirm('Are you sure you want to delete this quiz? This action cannot be undone.')) {
            chrome.storage.local.get('quizzes', (data) => {
                const quizzes = data.quizzes || [];
                const updatedQuizzes = quizzes.filter(q => q.id !== quizId);
                
                chrome.storage.local.set({ quizzes: updatedQuizzes }, () => {
                    this.quizzes = updatedQuizzes;
                    this.renderQuizzes();
                });
            });
        }
    }

    shareQuiz(quizId) {
        // Get the local server URL from background script
        chrome.runtime.sendMessage({ action: 'getServerStatus' }, (response) => {
            if (response && response.running) {
                const shareUrl = `${response.url}/play.html?id=${quizId}`;
                
                // Create a temporary input element to copy the URL
                const tempInput = document.createElement('input');
                tempInput.value = shareUrl;
                document.body.appendChild(tempInput);
                tempInput.select();
                document.execCommand('copy');
                document.body.removeChild(tempInput);
                
                alert('Quiz URL copied to clipboard! Share this URL with your students.');
            } else {
                alert('Please start the local server first to share quizzes.');
            }
        });
    }
}

// Initialize the quiz manager when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const manager = new QuizManager();
}); 