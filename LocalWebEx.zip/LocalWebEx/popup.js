// popup.js - Handles the extension popup functionality

document.addEventListener('DOMContentLoaded', () => {
    // Get UI elements
    const createQuizBtn = document.getElementById('createQuiz');
    const manageQuizzesBtn = document.getElementById('manageQuizzes');
    const viewAnalyticsBtn = document.getElementById('viewAnalytics');
    const startServerBtn = document.getElementById('startServer');
    const serverStatus = document.getElementById('serverStatus');
    const statusText = document.getElementById('status');
    const serverUrl = document.getElementById('serverUrl');

    // Check if server is already running
    chrome.runtime.sendMessage({ action: 'getServerStatus' }, (response) => {
        if (response && response.running) {
            updateServerStatus(true, response.url);
        }
    });

    // Add event listeners
    createQuizBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'quiz-builder.html' });
    });

    manageQuizzesBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'manage-quizzes.html' });
    });

    viewAnalyticsBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: 'analytics.html' });
    });

    startServerBtn.addEventListener('click', () => {
        startServerBtn.disabled = true;
        startServerBtn.textContent = 'Starting...';

        // Open the server.html page in a new tab
        chrome.tabs.create({ url: 'server.html' }, (tab) => {
            // Store the tab ID for later reference
            chrome.storage.local.set({ serverTabId: tab.id }, () => {
                updateServerStatus(true, 'http://localhost:8080');
                startServerBtn.textContent = 'Stop Server';
                startServerBtn.disabled = false;
                startServerBtn.removeEventListener('click', startServer);
                startServerBtn.addEventListener('click', stopServer);
            });
        });
    });

    function stopServer() {
        // Get the server tab ID
        chrome.storage.local.get(['serverTabId'], (result) => {
            if (result.serverTabId) {
                // Close the server tab
                chrome.tabs.remove(result.serverTabId, () => {
                    // Clear the stored tab ID
                    chrome.storage.local.remove(['serverTabId'], () => {
                        updateServerStatus(false);
                        startServerBtn.textContent = 'Start Local Server';
                        startServerBtn.removeEventListener('click', stopServer);
                        startServerBtn.addEventListener('click', () => {
                            chrome.tabs.create({ url: 'server.html' }, (tab) => {
                                chrome.storage.local.set({ serverTabId: tab.id }, () => {
                                    updateServerStatus(true, 'http://localhost:8080');
                                    startServerBtn.textContent = 'Stop Server';
                                    startServerBtn.removeEventListener('click', startServer);
                                    startServerBtn.addEventListener('click', stopServer);
                                });
                            });
                        });
                    });
                });
            } else {
                // If no tab ID is stored, just update the UI
                updateServerStatus(false);
                startServerBtn.textContent = 'Start Local Server';
                startServerBtn.removeEventListener('click', stopServer);
                startServerBtn.addEventListener('click', () => {
                    chrome.tabs.create({ url: 'server.html' }, (tab) => {
                        chrome.storage.local.set({ serverTabId: tab.id }, () => {
                            updateServerStatus(true, 'http://localhost:8080');
                            startServerBtn.textContent = 'Stop Server';
                            startServerBtn.removeEventListener('click', startServer);
                            startServerBtn.addEventListener('click', stopServer);
                        });
                    });
                });
            }
        });
    }

    function updateServerStatus(running, url) {
        if (running) {
            serverStatus.classList.remove('hidden');
            statusText.textContent = 'Online';
            statusText.style.color = '#2ecc71';
            serverUrl.textContent = url || 'http://localhost:8080';
        } else {
            serverStatus.classList.add('hidden');
            statusText.textContent = 'Offline';
            statusText.style.color = '#e74c3c';
            serverUrl.textContent = '';
        }
    }
}); 