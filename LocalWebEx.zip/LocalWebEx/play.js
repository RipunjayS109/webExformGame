// play.js - Handles the quiz play functionality

class QuizPlayer {
    constructor() {
        this.quizId = null;
        this.quizData = null;
        this.game = null;
        this.setupEventListeners();
        this.loadQuizData();
    }

    setupEventListeners() {
        document.getElementById('start-game-btn').addEventListener('click', () => this.startGame());
        document.getElementById('play-again-btn').addEventListener('click', () => this.resetGame());
    }

    loadQuizData() {
        // Get quiz ID from URL
        const urlParams = new URLSearchParams(window.location.search);
        this.quizId = urlParams.get('id');

        if (!this.quizId) {
            this.showError('No quiz ID provided. Please use a valid quiz link.');
            return;
        }

        // In a real implementation, this would fetch from the local server
        // For this demo, we'll use chrome.storage to simulate the server
        chrome.storage.local.get('quizzes', (data) => {
            const quizzes = data.quizzes || [];
            this.quizData = quizzes.find(q => q.id === this.quizId);

            if (!this.quizData) {
                this.showError('Quiz not found. It may have been deleted or is no longer available.');
                return;
            }

            // Update page title
            document.title = `${this.quizData.title} - Educational Quiz Game`;
        });
    }

    startGame() {
        const playerName = document.getElementById('player-name').value.trim();
        const playerRollNo = document.getElementById('player-rollno').value.trim();

        if (!playerName || !playerRollNo) {
            alert('Please enter both your name and roll number.');
            return;
        }

        if (!this.quizData) {
            this.showError('Quiz data not available. Please try again later.');
            return;
        }

        // Hide player info form and show game container
        document.getElementById('player-info-form').classList.add('hidden');
        document.getElementById('game-container').classList.remove('hidden');

        // Initialize the game
        const playerInfo = {
            name: playerName,
            rollNo: playerRollNo
        };

        this.game = new QuizGame(this.quizData, playerInfo);
    }

    resetGame() {
        // Hide game over screen and show player info form
        document.getElementById('game-over').classList.add('hidden');
        document.getElementById('player-info-form').classList.remove('hidden');
        
        // Clear input fields
        document.getElementById('player-name').value = '';
        document.getElementById('player-rollno').value = '';
    }

    showError(message) {
        const container = document.getElementById('player-info-form');
        container.innerHTML = `
            <div class="error-message">
                <h2>Error</h2>
                <p>${message}</p>
                <button class="primary-btn" onclick="window.location.reload()">Try Again</button>
            </div>
        `;
    }
}

// Initialize the quiz player when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const player = new QuizPlayer();
}); 