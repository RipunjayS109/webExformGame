let localServer = null;
const PORT = 8080;

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "startServer") {
        startLocalServer()
            .then(url => {
                sendResponse({ success: true, url: url });
            })
            .catch(error => {
                sendResponse({ success: false, error: error.message });
            });
        return true; // Keep the message channel open for async response
    } else if (message.action === "stopServer") {
        stopLocalServer();
        sendResponse({ success: true });
    } else if (message.action === "getServerStatus") {
        sendResponse({ 
            running: localServer !== null,
            url: localServer ? `http://localhost:${PORT}` : null
        });
    }
});

// Start local HTTP server
function startLocalServer() {
    return new Promise((resolve, reject) => {
        if (localServer) {
            resolve(`http://localhost:${PORT}`);
            return;
        }

        console.log("Starting local server on port", PORT);

        // In a Chrome extension, we can't directly start a Node.js server
        // Instead, we'll use a different approach:
        
        // 1. Create a simple HTML page that will be served
        const serverUrl = chrome.runtime.getURL('server.html');
        
        // 2. Open a new tab with the server page
        chrome.tabs.create({ url: serverUrl }, (tab) => {
            // 3. Store the tab ID for later reference
            localServer = {
                tabId: tab.id,
                port: PORT,
                running: true
            };
            
            // 4. Return the URL that can be used to access the server
            resolve(`http://localhost:${PORT}`);
        });
    });
}

// Stop the local server
function stopLocalServer() {
    if (localServer && localServer.tabId) {
        // Close the tab that's running the server
        chrome.tabs.remove(localServer.tabId, () => {
            localServer = null;
            console.log("Server stopped");
        });
    }
}