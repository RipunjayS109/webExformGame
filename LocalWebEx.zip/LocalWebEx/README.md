# Educational Quiz Game Extension

A Chrome extension that gamifies educational quizzes for teachers and students. This extension allows teachers to create interactive quizzes with a game-like interface where students can answer questions to progress through a game.

## Features

- **Quiz Builder**: Teachers can create quizzes with text and image-based questions
- **Game Mechanics**: Character moves across the screen as students answer questions correctly
- **Customizable Settings**: Teachers can set time limits and number of lives
- **Local Network Distribution**: Quizzes can be shared on a local network without requiring students to install the extension
- **Analytics**: Track student performance with detailed analytics

## Installation

1. Clone or download this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the directory containing the extension files

## Usage

### For Teachers

1. Click on the extension icon in your browser
2. Use the "Create New Quiz" button to build a quiz
3. Add questions, set time limits and lives
4. Save the quiz
5. Use the "Start Local Server" button to make the quiz available on your local network
6. Share the generated URL with students
7. View analytics to track student performance

### For Students

1. Open the shared quiz URL in your browser
2. Enter your name and roll number
3. Answer questions to progress through the game
4. Try to reach the finish line before running out of time or lives

## Project Structure

- `manifest.json`: Extension configuration
- `popup.html` & `popup.js`: Extension popup interface
- `background.js`: Handles extension background tasks
- `quiz-builder.html` & `quiz-builder.js`: Interface for creating quizzes
- `manage-quizzes.html` & `manage-quizzes.js`: Interface for managing quizzes
- `analytics.html` & `analytics.js`: Analytics dashboard
- `play.html` & `play.js`: Student interface for playing quizzes
- `game-engine.js`: Core game mechanics
- `styles.css`: Styling for all pages
- `server.html` & `server-ui.js`: Server interface for local network distribution

## Local Network Distribution

The extension uses a browser-based approach to distribute quizzes on the same network. This allows students to access quizzes without installing the extension.

### Starting the Server

1. Click on the extension icon in your browser
2. Click the "Start Local Server" button
3. A new tab will open with the server interface
4. Click the "Start Server" button in the server interface
5. The server will display URLs that you can share with students

### Accessing the Server from Other Devices

Once the server is running, you can access it from other devices on the same network using the URL displayed in the server interface.

### Troubleshooting

If you encounter an `ERR_CONNECTION_REFUSED` error:

1. Make sure the server is running (you should see a "Server is running" message in the server interface)
2. Check if your firewall is blocking the connection
3. Ensure all devices are on the same network
4. Try accessing the server using `localhost:8080` on the same machine to verify it's working

## Analytics

The analytics section provides detailed insights into student performance:

- Overall quiz statistics
- Question difficulty analysis
- Individual student performance tracking

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- Game assets are stored in the `assets` directory
- The extension uses Chrome's storage API for data persistence 